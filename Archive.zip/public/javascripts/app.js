/**
 * Created by huisu on 10/18/15.
 */
var  tweetmap = tweetmap  || {}
tweetmap.map = tweetmap.map|| {}

//config
tweetmap.map.config = {
    StatGoogleMap: '/data',
    NYCdata:'/nycdata'
}